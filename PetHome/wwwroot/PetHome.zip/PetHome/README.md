# MAS-Pet-Home
1) Por favor redimensione a janela para as proporções de um telemóvel antes de visualizar.
2) Se quiser eliminar todos os dados do LocalStorage, carregue em "Limpar cache", na secção de "Login" (recomendo que o faça antes e depois de ver cada projeto, para evitar problemas). Atenção: pelo conhecimento que tenho, o localstorage limpa todos os dados armazenados no browser, não apenas os pertencentes ao site.
3) Conta do doutor:
ID: 17345
Código: "código secreto" (com acento e espaço, mas sem aspas)
